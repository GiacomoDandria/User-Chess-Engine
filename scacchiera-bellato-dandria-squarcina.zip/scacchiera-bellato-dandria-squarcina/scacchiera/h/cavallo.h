//Autore: Giovanni Bellato

#pragma once
#include<string>
#include "scacchiera.h"
#include "traduttore.h"

struct cavallo 
{
	static bool moveCavalloCheck(std::string inputMovement);
};

