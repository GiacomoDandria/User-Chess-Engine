//AUTORE: MARCO SQUARCINA

#pragma once
#include "scacchiera.h"
#include "scacco.h"
#include "randomMoves.h"
#include<string>
#include<vector>

struct scaccomatto{
    //Check se è presente lo scaccomatto
    static bool check (scacchiera& board);
    
};
