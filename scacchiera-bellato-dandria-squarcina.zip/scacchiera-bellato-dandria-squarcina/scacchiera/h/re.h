//Autore: Giovanni Bellato

#pragma once
#include<string>
#include "scacchiera.h"
#include "traduttore.h"

struct re 
{
	static bool moveReCheck(std::string inputMovement);
};

