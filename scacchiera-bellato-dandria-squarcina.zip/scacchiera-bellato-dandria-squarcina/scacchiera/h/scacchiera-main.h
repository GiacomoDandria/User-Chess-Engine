//Autore: Giacomo D'Andria

#pragma once
#include <iostream>
#include<vector>
#include<limits>
#include<iostream>
#include <fstream>
#include "traduttore.h"
#include "scacchiera.h"
#include "alfiere.h"
#include "regina.h"
#include "re.h"
#include "cavallo.h"
#include "torre.h"
#include "computer.h"
#include "scacco.h"
#include "document.h"
#include "randomMoves.h"
#include "scaccomatto.h"

int main(int argCount, char* argVec[]);
