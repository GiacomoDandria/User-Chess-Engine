//Autore: Giovanni Bellato

#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "traduttore.h"
#include "scacchiera.h"

int main(int argCount, char* argVec[]);