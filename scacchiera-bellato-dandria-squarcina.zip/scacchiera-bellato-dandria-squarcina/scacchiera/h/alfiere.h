//Autore: Giovanni Bellato

#pragma once
#include<string>
#include<math.h>
#include "scacchiera.h"
#include "traduttore.h"

struct alfiere 
{
	static bool moveAlfiereCheck(std::string inputMovement);
};

