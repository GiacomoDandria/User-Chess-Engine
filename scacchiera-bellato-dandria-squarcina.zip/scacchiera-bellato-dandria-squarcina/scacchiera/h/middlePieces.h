//Autore: Giacomo D'Andria

#pragma once
#include<iostream>
#include"scacchiera.h"
#include"traduttore.h"


struct middlePieces 
{
	static bool check(scacchiera&,int,int,int,int);
};

