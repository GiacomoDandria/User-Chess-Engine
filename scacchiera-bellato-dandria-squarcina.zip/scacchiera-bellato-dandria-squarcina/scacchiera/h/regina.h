//Autore: Giacomo D'Andria

#pragma once
#include<string>
#include<math.h>
#include "scacchiera.h"
#include "traduttore.h"

struct regina {
	static bool moveReginaCheck(std::string inputMovement);
	
};

