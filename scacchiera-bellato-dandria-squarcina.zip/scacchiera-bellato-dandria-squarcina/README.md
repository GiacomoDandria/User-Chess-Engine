# LAB PROGETTAZIONE - PROGETTO FINALE
Autori: Bellato Giovanni, D'Andria Giacomo, Squarcina Marco

Durante la progettazione abbiamo effettuato i seguenti accorgimenti a queste problematiche:
 - La scelta random delle mosse da fare utilizza in realtà una funzione pseudorandom, infatti, dopo aver provato a implementarne una effettivamente random ci siamo accorti che le prestazioni dell'intero programma erano notevolmente ridotte dalla sua presenza. Per tale motivo abbiamo preferito sacrificare l'effettiva casualità della funzione pur di assicurare delle prestazioni (molto) migliori durante l'esecuzione del programma. La classe effettivamente random viene comunque inclusa all'interno delle cartelle di progetto.
 - La patta è stata semplificata ad un semplice contatore di 15 mosse, dopo le quali, se nessuno dei giocatori muove almeno un pedone, viene dichiarata e la partita risulta conclusa.
 - L'implementazione dello scaccomatto è stata semplificata considerando una partita conclusa se, per qualunque posizione in cui il re potrebbe spostarsi, esso rimarrebbe sotto scacco. Non sono stati considerati, per esempio, i casi in cui la pedina che sta facendo scacco possa essere mangiata a sua volta da qualcun'altro, o che il giocatore scelga di sacrificare una propria pedina per evitare che il re rimanga sotto scacco. Se si verificano le condizioni per lo scaccomatto la partita viene semplicmente dichiarata conclusa.
 - L'implementazione della pedina pedone non ha una classe propria perché ha bisogno di accedere alla scacchiera in sé per poter eseguire dei controlli. Per tale motivo essa è stata inclusa all'interno di scacchiera.cpp.


 - Naturalmente, come detto a lezione, il numero di classi scritte da ogni componente del gruppo varia a seconda della difficoltà della classe stessa. Il numero di classi firmate non implica quindi il carico di lavoro svolto.
